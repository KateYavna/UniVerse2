# UniVerse 

Welcome to my UniVerse project! It's simple social media app.

## Table of Contents

- [UniVerse](#universe)
  - [Table of Contents](#table-of-contents)
  - [Technologies](#technologies)
  - [Usage](#usage)
  - [Contributing](#contributing)
  - [Licence](#licence)
  - [Feedback](#feedback)

## Technologies
App was built using:
-  MinimalAPI
-  PostgreSQL
-  Dapper

## Usage

- Don't forget to configure your settings in the appsettings.json file.

## Contributing

We welcome contributions! To contribute to this project, follow these steps:

- Fork the repository.
- Create a new branch.
- Make your changes.
- Submit a pull request.

## Licence

This project is licensed under the MIT License.

## Feedback

Chat GPT is very knowlageble and friendly team member. Because all approuches were new to me our development weren't easy and lasted 2 days. This app is very easy it's tested and works properly.
